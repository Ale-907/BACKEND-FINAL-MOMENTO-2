package app.service.outputport;

import app.domain.PropertyOwner;

import java.util.List;
import java.util.Optional;

public interface PropertyOwnerRepository {

    public PropertyOwner savePropertyOwner(PropertyOwner propertyOwner);
    public List<PropertyOwner> selectAllPropertyOwners();
    public Optional<PropertyOwner> selectPropertyOwnerById(int id);
    public PropertyOwner updatePropertyOwner(int id , PropertyOwner propertyOwner);
    public void deletePropertyOwner(int id);

}
