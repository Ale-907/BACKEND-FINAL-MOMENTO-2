package app.service;

import app.domain.Property;
import app.domain.PropertyOwner;
import app.service.inputport.PropertyService;
import app.service.outputport.PropertyOwnerRepository;
import app.service.outputport.PropertyRepositoryInterface;

import java.util.List;
import java.util.Optional;

public class PropertyServiceImpl implements PropertyService {

    private final PropertyRepositoryInterface  propertyRepositoryInterface;
    private final PropertyOwnerRepository propertyOwnerRepository;
    public PropertyServiceImpl(PropertyRepositoryInterface  propertyRepositoryInterface , PropertyOwnerRepository propertyOwnerRepository){

        this.propertyRepositoryInterface = propertyRepositoryInterface;
        this.propertyOwnerRepository = propertyOwnerRepository;

    }



    @Override
    public Property createProperty(Integer propertyId, String propertyType, String address, String city, int propertyOwnerId, String isAvailable) {

        PropertyOwner propertyOwner = propertyOwnerRepository.selectPropertyOwnerById(propertyOwnerId).orElseThrow();

        Property property = new Property(propertyId, propertyType, address , city, propertyOwner, isAvailable);
        return property;
    }

    @Override
    public Optional<Property> findPropertyById(int id) {
        return Optional.empty();
    }

    @Override
    public List<Property> findProperties() {
        return List.of();
    }

    @Override
    public Property updateProperty(Integer propertyId, String propertyType, String address, String city, PropertyOwner propertyOwner, boolean isAvailable) {
        return null;
    }

    @Override
    public void deletePropertyById(int id) {

    }
}
