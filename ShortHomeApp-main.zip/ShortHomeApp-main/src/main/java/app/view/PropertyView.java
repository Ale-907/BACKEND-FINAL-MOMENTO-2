package app.view;

import app.domain.PropertyOwner;
import app.service.PropertyOwnerServiceImpl;
import app.service.inputport.PropertyService;
import app.service.validations.FormTypeValidator;

import java.util.Scanner;

public class PropertyView {


    private final PropertyService propertyService;

    public PropertyView(PropertyService propertyService) {
        this.propertyService = propertyService;
    }


    public void registerProperty() {

        System.out.println("Ingrese el id de la propiedad: ");

        Integer propertyId = FormTypeValidator.intValidator("Ingrese el Id de la propiedad");
        String propertyType = FormTypeValidator.stringValidator("Ingrese el tipo de propiedad");
        String address = FormTypeValidator.stringValidator("Ingrese la dirección de la propiedad");
        String city= FormTypeValidator.stringValidator("Ingrese la Ciudad");
        int propertyOwnerId = FormTypeValidator.intValidator("Ingrese el id del propietario");
        String isAvailable = FormTypeValidator.stringValidator("Disponible Y/N");

        propertyService.createProperty(propertyId, propertyType , address , city , propertyOwnerId , isAvailable);

    }

    public void showPropertyById() {

    }

    public void showAllProperties() {

    }

    public void updateProperty() {

    }

    public void deleteProperty() {

    }
}
