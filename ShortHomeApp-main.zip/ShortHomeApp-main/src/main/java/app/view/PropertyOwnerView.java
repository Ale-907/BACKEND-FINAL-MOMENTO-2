package app.view;

import app.domain.PropertyOwner;
import app.service.helpers.SetOwnerDocType;
import app.service.helpers.SetOwnerType;
import app.service.inputport.PropertyOwnerService;
import app.service.validations.FormTypeValidator;

import java.util.Date;
import java.util.List;

public class PropertyOwnerView{



    private final PropertyOwnerService propertyOwnerService;


    public PropertyOwnerView(PropertyOwnerService propertyOwnerService){
        this.propertyOwnerService = propertyOwnerService;
    }


    public void createPropertyOwner(){


        int id = FormTypeValidator.intValidator("Ingrese el id del propietario");
        System.out.println("Ingrese el tipo de documento del propietario");
        String docType = SetOwnerDocType.getDocType();
        String name = FormTypeValidator.stringValidator("Ingrese el nombre del propietario");
        System.out.println("Ingrese el apellido del propietario");
        String lastName = FormTypeValidator.stringValidator("Ingrese el apellido del propietario");
        String phone = FormTypeValidator.stringValidator("Ingrese el telefono del propietario");
        String email = FormTypeValidator.stringValidator("Ingrese el email del propietario");
        String address = FormTypeValidator.stringValidator("Ingrese la direccion del propietario");
        String password = FormTypeValidator.stringValidator("Ingrese la contraseña del propietario");

        System.out.println("Ingrese la fecha de nacimiento del propietario (formato: yyyy-MM-dd)");
        Date birthDate = getBirthDateFromInput();
        System.out.println("Ingrese el tipo de propietario: 1. Direct Owner, 2. Property Manager, 3. Real Estate Agency");
        String ownerType = SetOwnerType.getOwnerType();

        propertyOwnerService.createPropertyOwner(id, docType, name, lastName, phone, email, address, password, birthDate, ownerType);

    }


    public void showAllPropertiesOwners(){



        List<PropertyOwner> owners = propertyOwnerService.selectAllOwners();

        for(PropertyOwner owner: owners){
            System.out.println("Id: " +owner.getId() + "\n" +
                    "Tipo de Documento: " + owner.getDocType() + "\n" +
                    "Nombre: " + owner.getName() + "\n" +
                    "Apellido" + owner.getLastName() + "\n" +
                    "Telefono" + owner.getPhone() + "\n" +
                    "email: " + owner.getLastName() + "\n" +
                    "Direccion: " + owner.getAddress()+ "\n" +
                    "Password: " + owner.getPassword() + "\n" +
                    "Fecha de Nacimiento: " + owner.getBirthDate() + "\n" +
                    "Tipo de Propietario: " + owner.getOwnerType()
            );
        }

    }


    public void showPropertyOwnerById(){

        int id = FormTypeValidator.intValidator("Ingrese el id del propietario a consultar");

        PropertyOwner owner = propertyOwnerService.selectOwnerById(id);

        System.out.println("Id: " +owner.getId() + "\n" +
                "Tipo de Documento: " + owner.getDocType() + "\n" +
                "Nombre: " + owner.getName() + "\n" +
                "Apellido" + owner.getLastName() + "\n" +
                "Telefono" + owner.getPhone() + "\n" +
                "email: " + owner.getLastName() + "\n" +
                "Direccion: " + owner.getAddress()+ "\n" +
                "Password: " + owner.getPassword() + "\n" +
                "Fecha de Nacimiento: " + owner.getBirthDate() + "\n" +
                "Tipo de Propietario: " + owner.getOwnerType()
        );

    }


    public void updatePropertyOwner(){
        System.out.println("Actualizar propietario");
        int id = FormTypeValidator.intValidator("Ingrese el id del propietario a Actualizar");

        System.out.println("Ingrese el tipo de documento del propietario");
        String docType = SetOwnerDocType.getDocType();
        String name = FormTypeValidator.stringValidator("Ingrese el nombre del propietario");
        System.out.println("Ingrese el apellido del propietario");
        String lastName = FormTypeValidator.stringValidator("Ingrese el apellido del propietario");
        String phone = FormTypeValidator.stringValidator("Ingrese el telefono del propietario");
        String email = FormTypeValidator.stringValidator("Ingrese el email del propietario");
        String address = FormTypeValidator.stringValidator("Ingrese la direccion del propietario");
        String password = FormTypeValidator.stringValidator("Ingrese la contraseña del propietario");

        System.out.println("Ingrese la fecha de nacimiento del propietario (formato: yyyy-MM-dd)");
        Date birthDate = getBirthDateFromInput();
        System.out.println("Ingrese el tipo de propietario: 1. Direct Owner, 2. Property Manager, 3. Real Estate Agency");
        String ownerType = SetOwnerType.getOwnerType();

        propertyOwnerService.updatePropertyOwner(id, docType, name, lastName, phone, email, address, password, birthDate, ownerType);
    }


    public void deletePropertyOwner(){
        System.out.println("Eliminar propietario");
        int id = FormTypeValidator.intValidator("Ingrese el id del propietario a eliminar");
        propertyOwnerService.deleteOwner(id);

    }


    // Metodos Helper , luego se convertiran en metodos de la clase service para que sean llamados desde el controller

    public Date getBirthDateFromInput() {

        String birthDateString = FormTypeValidator.stringValidator("Ingrese la fecha de nacimiento del propietario (formato: yyyy-MM-dd): ");
        Date birthDate = null;
        try {
            birthDate = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(birthDateString);
        } catch (java.text.ParseException e) {
            System.out.println("Formato de fecha inválido. Por favor, ingrese la fecha en el formato correcto.");
        }
        return birthDate;
    }






}
