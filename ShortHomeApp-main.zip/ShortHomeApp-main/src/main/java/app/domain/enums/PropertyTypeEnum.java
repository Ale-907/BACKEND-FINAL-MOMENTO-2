package app.domain.enums;

public enum PropertyTypeEnum {


    HOUSE("Casa"),
    APARMENT("Apartamento"),
    BEDROOM("Habitación"),
    SHAREROOM("Habitación compartida");

    private final String value;

    PropertyTypeEnum(String value){
        this.value = value;
    }


    public String getValue(){
        return value;
    }

}
