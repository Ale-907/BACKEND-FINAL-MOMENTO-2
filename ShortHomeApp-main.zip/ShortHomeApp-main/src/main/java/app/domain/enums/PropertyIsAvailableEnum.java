package app.domain.enums;

public enum PropertyIsAvailableEnum {


    AVAILABLE("Disponible"),
    NON_AVAILABLE("No disponible");

    private final String value;

    PropertyIsAvailableEnum(String value){
        this.value = value;
    }

    public String getValue(){
        return value;
    }
}
