package app.configuration;

import app.domain.PropertyOwner;
import app.persistence.dbconnection.DataBaseConnection;
import app.persistence.mapper.PropertyOwnerMapper;
import app.persistence.mapper.RowMapper;
import app.persistence.repository.PropertyOwnerRepositoryDB;
import app.persistence.repository.PropertyOwnerRepositoryImpl;
import app.persistence.repository.PropertyRepositoryImpl;
import app.service.PropertyOwnerServiceImpl;
import app.service.PropertyServiceImpl;
import app.service.inputport.PropertyOwnerService;
import app.service.inputport.PropertyService;
import app.service.outputport.PropertyOwnerRepository;
import app.service.outputport.PropertyRepositoryInterface;
import app.userinterface.UserInterface;
import app.view.PropertyOwnerView;
import app.view.PropertyView;

import java.sql.Connection;

public class Config {

    public static UserInterface createUserInterface() {

        Connection connection = DataBaseConnection.getInstance().getConnection();

        RowMapper<PropertyOwner> rowMapper = new PropertyOwnerMapper();

        PropertyOwnerRepository propertyOwnerRepository = new PropertyOwnerRepositoryDB(connection, rowMapper);
        PropertyOwnerService propertyOwnerService = new PropertyOwnerServiceImpl(propertyOwnerRepository);
        PropertyOwnerView propertyOwnerView = new PropertyOwnerView(propertyOwnerService);

        PropertyRepositoryInterface propertyRepositoryInterface = new PropertyRepositoryImpl();
        PropertyService propertyService = new PropertyServiceImpl(propertyRepositoryInterface,propertyOwnerRepository);
        PropertyView propertyView = new PropertyView(propertyService);

        return new UserInterface(propertyOwnerView, propertyView);


    }
}
