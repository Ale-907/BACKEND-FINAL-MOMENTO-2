package app.persistence.repository;

import app.domain.Property;
import app.service.outputport.PropertyRepositoryInterface;

import java.sql.Connection;
import java.util.List;
import java.util.Optional;

public class PropertyRepositoryAdapterDB implements PropertyRepositoryInterface {


    private final Connection dbConnection;

    PropertyRepositoryAdapterDB(Connection dbConnection){
        this.dbConnection = dbConnection;

    }


    @Override
    public Property saveProperty(Property property) {

        String sql = "INSERT INTO ";
        /*
        try(){

        }catch (){


        }*/


        return property;
    }

    @Override
    public Optional<Property> selectPropertyById(int id) {
        return Optional.empty();
    }

    @Override
    public List<Property> selectAllProperties() {
        return List.of();
    }

    @Override
    public Property updateProperty(Property property) {
        return null;
    }

    @Override
    public void deleteProperty(int id) {

    }
}
