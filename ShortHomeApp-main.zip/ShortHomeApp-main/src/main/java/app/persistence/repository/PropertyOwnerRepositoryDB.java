package app.persistence.repository;

import app.domain.PropertyOwner;
import app.persistence.mapper.RowMapper;
import app.service.outputport.PropertyOwnerRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class PropertyOwnerRepositoryDB implements PropertyOwnerRepository {


    private final Connection dbConnection;
    private final RowMapper rowMapper;

    public PropertyOwnerRepositoryDB(Connection dbConnection, RowMapper rowMapper){
        this.dbConnection = dbConnection;
        this.rowMapper = rowMapper;
    }


    @Override
    public PropertyOwner savePropertyOwner(PropertyOwner propertyOwner) {

        String sql = "INSERT INTO property_owner(id_property_owner , doc_type , name , last_name, phone , email , address , password_pr , birthday , owner_type)VALUES(?,?,?,?,?,?,?,?,?,?)";

        try(PreparedStatement ps= dbConnection.prepareStatement(sql)){

            setPropertyOwnerParams(ps, propertyOwner);

            ps.executeUpdate();

            System.out.println("Se registro propietario en la BD");


        }catch(SQLException e){
            throw new RuntimeException("NO se pudo crear el propietario" + e.getMessage());
        }

        return propertyOwner;
    }

    @Override
    public List<PropertyOwner> selectAllPropertyOwners() {

        List<PropertyOwner> owners = new ArrayList<>();

        String sql = "SELECT * FROM property_owner";

        try(PreparedStatement ps = dbConnection.prepareStatement(sql)){

            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                  owners.add((PropertyOwner) rowMapper.mapRow(rs));
            }

        }catch (SQLException e){
            throw new RuntimeException("Error al consultar los propietarios" + e.getMessage());
        }

        return owners;
    }

    @Override
    public Optional<PropertyOwner> selectPropertyOwnerById(int id) {


        String sql = "SELECT * FROM property_owner WHERE id_property_owner = ?";

        try(PreparedStatement ps = dbConnection.prepareStatement(sql)){

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                return Optional.of((PropertyOwner) rowMapper.mapRow(rs));
            }



        }catch (SQLException e){
            throw new RuntimeException("Error al consultar los propietarios" + e.getMessage());
        }

        return Optional.empty();
    }

    @Override
    public PropertyOwner updatePropertyOwner(int id ,PropertyOwner propertyOwner) {

        String sql = "UPDATE property_owner SET id_property_owner = ? , doc_type = ? , name = ? , last_name = ? , phone = ? , email = ? , address = ? , password_pr = ? , birthday = ? , owner_type = ? WHERE id_property_owner = ?";

        try(PreparedStatement ps = dbConnection.prepareStatement(sql)){

            setPropertyOwnerParams(ps, propertyOwner);
            ps.setInt(11, id);
            ps.executeUpdate();

            System.out.println("Se actualizo propietario en la BD");



        }catch (SQLException e){
            throw new RuntimeException("Error al consultar los propietarios" + e.getMessage());
        }

        return propertyOwner;
    }

    @Override
    public void deletePropertyOwner(int id) {

        String sql = "DELETE FROM property_owner WHERE id_property_owner = ?";

        try(PreparedStatement ps = dbConnection.prepareStatement(sql)){

            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("Se elimino propietario en la BD");

        }catch (SQLException e){
            throw new RuntimeException("Error al consultar los propietarios" + e.getMessage());
        }
    }


    private void setPropertyOwnerParams(PreparedStatement ps, PropertyOwner propertyOwner) throws SQLException{

        ps.setInt(1,propertyOwner.getId());
        ps.setString(2, propertyOwner.getDocType());
        ps.setString(3, propertyOwner.getName());
        ps.setString(4, propertyOwner.getLastName());
        ps.setString(5, propertyOwner.getPhone());
        ps.setString(6, propertyOwner.getEmail());
        ps.setString(7, propertyOwner.getAddress());
        ps.setString(8, propertyOwner.getPassword());
        ps.setDate(9, new java.sql.Date(propertyOwner.getBirthDate().getTime()));
        ps.setString(10, propertyOwner.getOwnerType());

    }
}

