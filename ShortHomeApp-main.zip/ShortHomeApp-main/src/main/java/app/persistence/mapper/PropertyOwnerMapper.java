package app.persistence.mapper;

import app.domain.PropertyOwner;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PropertyOwnerMapper implements RowMapper<PropertyOwner> {

    @Override
    public PropertyOwner mapRow(ResultSet rs) throws SQLException {

        PropertyOwner propertyOwner = new PropertyOwner();

        propertyOwner.setId(rs.getInt("id_property_owner"));
        propertyOwner.setDocType(rs.getString("doc_type"));
        propertyOwner.setName(rs.getString("name"));
        propertyOwner.setLastName(rs.getString("last_name"));
        propertyOwner.setPhone(rs.getString("phone"));
        propertyOwner.setEmail(rs.getString("email"));
        propertyOwner.setAddress(rs.getString("address"));
        propertyOwner.setPassword(rs.getString("password_pr"));
        propertyOwner.setBirthDate(rs.getDate("birthday"));
        propertyOwner.setOwnerType(rs.getString("owner_type"));

        return propertyOwner;
    }






}
